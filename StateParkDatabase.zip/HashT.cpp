

#include "HashT.hpp"
#include "LinkedList.hpp"
#include "ListNode.hpp"
#include <iostream>
using namespace std;

HashCell::HashCell()
{
    count = 0;
    //head = new ListNode;
    //head->setForw(head);
    //head->setBack(head);

}

HashCell::~HashCell()
{

}

HashCell::HashCell(StatePark p, int c)
{
    park = p;
    count = c;
    //head = h;

}

void HashCell::insertHash(StatePark dataIn)
{
    list.insertNodeHash(dataIn);
    count++;

}

void HashCell::printHashCell(HashCell dataIn)
{
    dataIn.list.printHashList(dataIn.list.printNodeHash);
}

void HashCell :: Search(HashCell dataIn, StatePark &returnedItem,string n)
{
    dataIn.list.searchList(returnedItem,n);
}

void HashCell :: Delete(HashCell dataIn, string n)
{
    dataIn.list.deleteNodeHash(n);
}

void HashCell :: getFirstList(HashCell dataIn, StatePark & returnedItem)
{
    ListNode* temp = dataIn.list.getHead();
    returnedItem = temp->getPark();
    //call delete node
    dataIn.list.deleteNode(returnedItem);


}
