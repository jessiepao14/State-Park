//
//  HashFunc.hpp
//  TeamProject
//
//  Created by Jessie Pao on 12/1/19.
//  Copyright © 2019 Jessie Pao. All rights reserved.
//

#ifndef HashFunc_hpp
#define HashFunc_hpp

#include "HashT.hpp"

class HashFunc
{
    public:
        HashFunc();
        ~HashFunc();
        void buildHash(StatePark);
        void printArray();
        double getLoadFactor();
        int getNumOfCollisions();
        int getSizeOfArray() { return sizeOfArray; }
        bool SearchHash(string, StatePark &);
        void DeleteHashCell(string);


    private:
        HashCell *hashArray;
        int numOfCollisions;
        double loadFactor;
        int sizeOfArray;

        //private functions
        void _insertHash(ListNode*);
        int _hashName(string);
        void reHash();
        bool isPrime(int n);
        int nextPrime(int N);

};
#endif /* HashFunc_hpp */
